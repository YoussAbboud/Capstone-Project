package com.example.finalproject;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


public class project_add extends Fragment {

    ImageButton addButton;
    ImageButton createButton;
    ImageButton backButton;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;

    EditText finalEditText;

    String userID;
    int start = 1;
    int i = 1;

    public project_add() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_project_add, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();

        View view = getView();

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        LinearLayout mainlinearLayout = view.findViewById(R.id.project_add_linear_layout);

        addButton = view.findViewById(R.id.add_image_button);
        createButton = view.findViewById(R.id.create_project_image_button);
        backButton = view.findViewById(R.id.back_image_button);

        EditText projectTitle = view.findViewById(R.id.project_title_edit_text);

        EditText projectLocation = view.findViewById(R.id.project_location_edit_text);

        EditText projectBudget = view.findViewById(R.id.project_budget_edit_text);

        EditText taskTitle = view.findViewById(R.id.edit_text_task);

        EditText taskDescription = view.findViewById(R.id.edit_text_description);

        EditText taskLabor = view.findViewById(R.id.edit_text_labor_option);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), MainActivity.class));
                getActivity().finish();
            }
        });


        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userID = fAuth.getCurrentUser().getUid();
                String pTitle = projectTitle.getText().toString();
                String pLocation = projectLocation.getText().toString();
                String pBudget = projectBudget.getText().toString();
                String pTaskTitle = taskTitle.getText().toString();
                String pTaskDes = taskDescription.getText().toString();
                String pTaskLab = taskLabor.getText().toString();

                if (TextUtils.isEmpty(pTitle)) {
                    projectTitle.setError("Project Title is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pLocation)) {
                    projectLocation.setError("Project Location is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pBudget)) {
                    projectBudget.setError("Project Budget is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pTaskTitle)) {
                    taskTitle.setError("A Task Title is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pTaskDes)) {
                    taskDescription.setError("A Task Description is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pTaskLab)) {
                    taskLabor.setError("A Task Labor Option is Required.");
                    return;
                }


                DocumentReference documentReference = fStore.collection("users").document(userID).collection("projects").document(pTitle);




                    Map<String, Object> project = new HashMap<>();
                    project.put("title", pTitle);
                    project.put("location", pLocation);
                    project.put("budget", pBudget);

                    documentReference.set(project);

                    DocumentReference documentReference2 = fStore.collection("users").document(userID).collection("projects").document(pTitle).collection("tasks").document(pTaskTitle);
                    Map<String, Object> Task = new HashMap<>();
                    Task.put("title", pTaskTitle);
                    Task.put("description", pTaskDes);
                    Task.put("labor", pTaskLab);

                    documentReference2.set(Task);
                    i++;
                    taskTitle.setText("");
                    taskTitle.setHint("Task" + i);
                    taskDescription.setText("");
                    taskLabor.setText("");

                    createButton.setVisibility(View.GONE);
                    addButton.setVisibility(View.VISIBLE);


                    Toast.makeText(getActivity(), "Project Created!", Toast.LENGTH_SHORT).show();





            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userID = fAuth.getCurrentUser().getUid();
                String pTitle = projectTitle.getText().toString();
                String pLocation = projectLocation.getText().toString();
                String pBudget = projectBudget.getText().toString();
                String pTaskTitle = taskTitle.getText().toString();
                String pTaskDes = taskDescription.getText().toString();
                String pTaskLab = taskLabor.getText().toString();

                if (TextUtils.isEmpty(pTitle)) {
                    projectTitle.setError("Project Title is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pLocation)) {
                    projectLocation.setError("Project Location is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pBudget)) {
                    projectBudget.setError("Project Budget is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pTaskTitle)) {
                    taskTitle.setError("A Task Title is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pTaskDes)) {
                    taskDescription.setError("A Task Description is Required.");
                    return;
                }
                if (TextUtils.isEmpty(pTaskLab)) {
                    taskLabor.setError("A Task Labor Option is Required.");
                    return;
                }

                DocumentReference documentReference2 = fStore.collection("users").document(userID).collection("projects").document(pTitle).collection("tasks").document("task" + i);
                Map<String, Object> Task = new HashMap<>();
                Task.put("title", pTaskTitle);
                Task.put("description", pTaskDes);
                Task.put("labor", pTaskLab);

                documentReference2.set(Task);
                i++;
                taskTitle.setText("");
                taskTitle.setHint("Task " + i);
                taskDescription.setText("");
                taskDescription.setHint("Description");
                taskLabor.setText("");
                taskLabor.setHint("Labor Option");


            }
        });


    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

    }
}