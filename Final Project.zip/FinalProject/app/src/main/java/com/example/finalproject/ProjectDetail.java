package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.firebase.ui.firestore.SnapshotParser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;

public class ProjectDetail extends AppCompatActivity implements FirestoreTaskAdapter.OnListItemClick {

    String ID = "";
    private OnItemClickListener listener;

    public static String PROJECT_TITLE = "project_title";
    public static String PROJECT_LOCATION = "project_location";
    public static String PROJECT_BUDGET = "project_budget";

    ImageButton backButton, saveButton, deleteButton, creatButton;
    ImageView projectImageButton;

    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firebaseFirestore;
    private RecyclerView mFirestoreList;

    static private FirestoreTaskAdapter adapter;

    public static String USER_ID = "user_id";
    String title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_detail);

        projectImageButton = findViewById(R.id.project_detail_image_view);

        Intent intent = getIntent();

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();



        if(intent.getStringExtra(USER_ID) == null){
            ID = firebaseAuth.getCurrentUser().getUid();
        }
        else{
            ID = intent.getStringExtra(USER_ID);
        }


        mFirestoreList = findViewById(R.id.recycler_view_tasks);

        title = intent.getStringExtra(PROJECT_TITLE);
        String location = intent.getStringExtra(PROJECT_LOCATION);
        String budget = intent.getStringExtra(PROJECT_BUDGET);

        TextView textViewTitle = findViewById(R.id.project_detail_title);
        TextView textViewLocation = findViewById(R.id.project_detail_location);
        TextView textViewBudget = findViewById(R.id.project_detail_budget);

        EditText editTextLocation = findViewById(R.id.project_detail_location_edit_text);
        EditText editTextBudget = findViewById(R.id.project_detail_budget_edit_text);

        textViewTitle.setText("Title: "+title);
        textViewLocation.setText("Location: "+location);
        textViewBudget.setText("Budget: $"+budget);

        saveButton = findViewById(R.id.save_edit_image_button);

        deleteButton = findViewById(R.id.project_detail_delete_image_button);

        creatButton = findViewById(R.id.task_detail_create_button);

        creatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1 = new Intent(ProjectDetail.this , NewTask.class);
                intent1.putExtra(NewTask.PROJECT_TITLE , title);
                intent1.putExtra(NewTask.USER_ID , ID);
                startActivity(intent1);

            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder1 = new AlertDialog.Builder(ProjectDetail.this);
                builder1.setIcon(R.drawable.baseline_delete_24);
                builder1.setTitle("Delete " + title + ":");
                builder1.setMessage("Are you sure you want to delete your PROJECT?");
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {


                                dialog.cancel();

                                DocumentReference documentReference = firebaseFirestore.collection("users").document(ID).collection("projects").document(title);
                                documentReference.delete();

                                finish();
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();
            }
        });

        projectImageButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                textViewLocation.setText("LOCATION:");
                textViewBudget.setText("BUDGET: $");

                editTextLocation.setVisibility(View.VISIBLE);
                editTextLocation.setText(location);
                editTextBudget.setVisibility(View.VISIBLE);
                editTextBudget.setText(budget);
                saveButton.setVisibility(View.VISIBLE);

                return false;
            }
        });

        backButton = findViewById(R.id.project_detail_back_button);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProjectDetail.this , RecentProject.class));
                finish();
            }
        });




        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tLocation = editTextLocation.getText().toString();
                String tBudget = editTextBudget.getText().toString();


                if (TextUtils.isEmpty(tLocation)) {
                    editTextLocation.setError("Task Location is Required.");
                    return;
                }
                if (TextUtils.isEmpty(tBudget)) {
                    editTextBudget.setError("Task Budget is Required.");
                    return;
                }



                DocumentReference documentReference = firebaseFirestore.collection("users").document(ID).collection("projects").document(title);
                        documentReference.update(
                        "location" , tLocation,
                "budget", tBudget
                ).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(ProjectDetail.this, "Project Updated", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                        else{
                            Toast.makeText(ProjectDetail.this, "Failed Updating Project", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });






        //Query
        Query query = firebaseFirestore.collection("users").document(ID).collection("projects").document(title).collection("tasks");

        //RecyclerOptions
        FirestoreRecyclerOptions<TasksModel> options = new FirestoreRecyclerOptions.Builder<TasksModel>()
                .setQuery(query, new SnapshotParser<TasksModel>() {
                    @NonNull
                    @Override
                    public TasksModel parseSnapshot(@NonNull DocumentSnapshot snapshot) {
                        TasksModel tasksModel = snapshot.toObject(TasksModel.class);
                        String taskId = snapshot.getId();
                        Log.d("MODEL_TITLE" , title);
                        tasksModel.setTask_Id(taskId);
                        return tasksModel;
                    }
                })
                .build();



        adapter = new FirestoreTaskAdapter(options , this);

        mFirestoreList.setHasFixedSize(true);
        mFirestoreList.setLayoutManager(new LinearLayoutManager(this));
        mFirestoreList.setAdapter(adapter);

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0 ,
                ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                adapter.deleteTask(viewHolder.getAdapterPosition());
                adapter.notifyItemRemoved(viewHolder.getAdapterPosition());
            }
        }).attachToRecyclerView(mFirestoreList);


    }




    @Override
    public void onItemClick(TasksModel snapshot , int position) {
        Intent intent = new Intent(this , TaskEdit.class);
        intent.putExtra(TaskEdit.PROJECT_T, title);
        intent.putExtra(TaskEdit.TASK_TITLE, snapshot.getTitle());
        intent.putExtra(TaskEdit.TASK_DESCRIPTION, snapshot.getDescription());
        intent.putExtra(TaskEdit.TASK_LABOR, snapshot.getLabor());
        intent.putExtra(TaskEdit.USER_ID , ID);

        startActivity(intent);
        Log.d("ITEM_CLICK" , "Task an item: ");
    }


    public interface OnItemClickListener{
        void onItemClicked(DocumentSnapshot documentSnapshot , int position);
    }

    public void setOnItemClickListener(ProjectDetail.OnItemClickListener listener)
    {
        this.listener = listener;
    }


    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}