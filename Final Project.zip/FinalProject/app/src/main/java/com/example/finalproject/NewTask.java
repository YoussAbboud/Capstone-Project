package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class NewTask extends AppCompatActivity {

    public static String PROJECT_TITLE = "project_title";
    public static String USER_ID = "user_id";


    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firebaseFirestore;


    String userID = "";

    EditText editTextTitle , editTextDesc , editTextLabor;

    ImageButton createButton, backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_task);

        Intent intent = getIntent();

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        if(intent.getStringExtra(USER_ID) == null) {
            userID = firebaseAuth.getCurrentUser().getUid();
        }
        else
        {
            userID = intent.getStringExtra(USER_ID);
        }

        String pTitle = intent.getStringExtra(PROJECT_TITLE);

        createButton = findViewById(R.id.task_create_button);

        backButton = findViewById(R.id.create_task_back_button);

        editTextTitle = findViewById(R.id.task_create_title);
        editTextDesc = findViewById(R.id.task_create_description);
        editTextLabor = findViewById(R.id.task_create_new_labor);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String tTitle = editTextTitle.getText().toString();
                String tDesc = editTextDesc.getText().toString();
                String tLabor = editTextLabor.getText().toString();

                if (TextUtils.isEmpty(tTitle)) {
                    editTextTitle.setError("Task Title is Required.");
                    return;
                }
                if (TextUtils.isEmpty(tDesc)) {
                    editTextDesc.setError("Task Description is Required.");
                    return;
                }
                if (TextUtils.isEmpty(tLabor)) {
                    editTextLabor.setError("Task Labor Option is Required.");
                    return;
                }

                DocumentReference documentReference = firebaseFirestore.collection("users").document(userID).collection("projects").document(pTitle).collection("tasks").document(tTitle);


                    Map<String, Object> task = new HashMap<>();
                    task.put("title", tTitle);
                    task.put("description", tDesc);
                    task.put("labor", tLabor);

                    documentReference.set(task);

                Toast.makeText(NewTask.this, "Task Created!", Toast.LENGTH_SHORT).show();


                finish();



            }
        });






    }
}