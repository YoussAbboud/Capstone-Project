package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class TaskEdit extends AppCompatActivity {

    public static String PROJECT_T = "project_title";
    public static String TASK_TITLE = "task_title";
    public static String TASK_DESCRIPTION = "task_location";
    public static String TASK_LABOR = "task_budget";
    public static String USER_ID = "user_id";

    TextView taskTitle;
    EditText  editDescription, editLabor;

    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firebaseFirestore;
    String userID = "";


    ImageButton saveButton, backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_edit);

        Intent intent = getIntent();

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        if(intent.getStringExtra(USER_ID) == null) {
            userID = firebaseAuth.getCurrentUser().getUid();
        }
        else
        {
            userID = intent.getStringExtra(USER_ID);
        }
        String pTitle = intent.getStringExtra(PROJECT_T);
        String title = intent.getStringExtra(TASK_TITLE);
        String description = intent.getStringExtra(TASK_DESCRIPTION);
        String labor = intent.getStringExtra(TASK_LABOR);

        saveButton = findViewById(R.id.task_save_button);
        backButton = findViewById(R.id.task_edit_back_button);

        taskTitle = findViewById(R.id.task_title_edit_text);
        taskTitle.setText(title);

        editDescription = findViewById(R.id.task_desciption_edit_text);
        editDescription.setText(description);
        editLabor = findViewById(R.id.task_labor_edit_text);
        editLabor.setText(labor);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String tDescription = editDescription.getText().toString();
                String tLabor = editLabor.getText().toString();

                if (TextUtils.isEmpty(tDescription)) {
                    editDescription.setError("Task Description is Required.");
                    return;
                }
                if (TextUtils.isEmpty(tLabor)) {
                    editLabor.setError("Task Labor Option is Required.");
                    return;
                }



                DocumentReference documentReference = firebaseFirestore.collection("users").document(userID).collection("projects").document(pTitle).collection("tasks").document(title);


                documentReference.update(
                        "description" , tDescription,
                        "labor", tLabor
                ).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(TaskEdit.this, "Task Updated", Toast.LENGTH_SHORT).show();
                            finish();

                        }
                        else{
                            Toast.makeText(TaskEdit.this, "Failed Updating Task", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });



    }
}