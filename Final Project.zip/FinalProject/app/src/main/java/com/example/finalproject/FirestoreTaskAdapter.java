package com.example.finalproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class FirestoreTaskAdapter extends FirestoreRecyclerAdapter<TasksModel , FirestoreTaskAdapter.TasksViewHolder> {

    private OnListItemClick onListItemClick;


    public FirestoreTaskAdapter(@NonNull FirestoreRecyclerOptions<TasksModel> options , OnListItemClick onListItemClick) {
        super(options);
        this.onListItemClick = onListItemClick;
    }


    @Override
    protected void onBindViewHolder(@NonNull TasksViewHolder holder, int position, @NonNull TasksModel model) {
        holder.task_title.setText("Title: "+model.getTitle());
        holder.task_description.setText("Description: "+model.getDescription());
        holder.task_labor.setText("Labor Option: "+model.getLabor());


    }

    @NonNull
    @Override
    public TasksViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_project_item , parent , false);

        return new TasksViewHolder(view);
    }

    public void deleteTask(int position)
    {
        getSnapshots().getSnapshot(position).getReference().delete();
    }

    class TasksViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView task_title;
        private TextView task_description;
        private TextView task_labor;

        public TasksViewHolder(@NonNull View itemView) {
            super(itemView);

            task_title = itemView.findViewById(R.id.task_recent_title);
            task_description = itemView.findViewById(R.id.task_recent_description);
            task_labor = itemView.findViewById(R.id.task_recent_labor);

            itemView.setOnClickListener(this);

        }


        @Override
        public void onClick(View v) {
            onListItemClick.onItemClick(getItem(getAdapterPosition()) , getAdapterPosition());
        }
    }

    public interface OnListItemClick {
        void onItemClick(TasksModel snapshot , int position);
    }

}
