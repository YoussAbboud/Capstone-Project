package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    EditText lEmail , lPassword;
    Button loginButton;
    TextView createButton;
    ProgressBar progressBar;
    FirebaseAuth fAuth;

    ImageView hidePass, showPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        lEmail = findViewById(R.id.email_login_edit_text);
        lPassword = findViewById(R.id.password_login_edit_text);

        createButton = findViewById(R.id.register_text_view);
        loginButton = findViewById(R.id.login_button);

        hidePass = findViewById(R.id.hide_password_checkbox);
        showPass = findViewById(R.id.show_password_checkbox);

        fAuth = FirebaseAuth.getInstance();

        progressBar = findViewById(R.id.progressBar_2);

        showPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    lPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    showPass.setVisibility(View.GONE);

                    hidePass.setVisibility(View.VISIBLE);


            }
        });

        hidePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hidePass.setVisibility(View.GONE);
                lPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                showPass.setVisibility(View.VISIBLE);
            }
        });



        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = lEmail.getText().toString();
                String password = lPassword.getText().toString();

                if(TextUtils.isEmpty(email))
                {
                    lEmail.setError("Email is Required.");
                    return;
                }

                if(TextUtils.isEmpty(password))
                {
                    lPassword.setError("Password is Required.");
                    return;
                }

                if(password.length() < 6){
                    lPassword.setError("Password must be bigger then 6 characters");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);

               fAuth.signInWithEmailAndPassword(email , password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                   @Override
                   public void onComplete(@NonNull Task<AuthResult> task) {
                       if(task.isSuccessful())
                       {

                           if (fAuth.getCurrentUser().isEmailVerified())
                           {
                               Toast.makeText(Login.this, "Logged In Successfully", Toast.LENGTH_SHORT).show();
                               finish();
                               startActivity(new Intent(getApplicationContext(), MainActivity.class));
                               progressBar.setVisibility(View.GONE);
                           }
                           else{
                               lEmail.setError("Please verify your email");
                           }


                       }
                       else
                       {
                           Toast.makeText(Login.this, "Error while Logging in: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                           progressBar.setVisibility(View.GONE);
                       }
                   }
               }).addOnFailureListener(new OnFailureListener() {
                   @Override
                   public void onFailure(@NonNull Exception e) {
                       Log.d("This Login" , e.getMessage());
                   }
               });
            }
        });



        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(getApplicationContext() , Register.class));
            }
        });


    }


}