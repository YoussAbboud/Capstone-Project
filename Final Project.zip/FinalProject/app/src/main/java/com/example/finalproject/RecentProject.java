package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.firebase.ui.firestore.SnapshotParser;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

public class RecentProject extends AppCompatActivity implements FirestoreAdapter.OnListItemClick, FirestoreSyncAdapter.OnListItemClick2{
    private OnItemClickListener listener;

    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firebaseFirestore;
    private RecyclerView mFirestoreList;
    private RecyclerView mFirestoreList2;

    static private FirestoreAdapter adapter;
    static private FirestoreSyncAdapter adapter2;

    TextView syncedProjects;

    String userID ;
    static String collaboraterID = " ";
    Query query2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_project);


        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        toolbar.setTitle("");

        setSupportActionBar(toolbar);
        toolbar.setLeft(R.drawable.baseline_home_24);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        userID = firebaseAuth.getCurrentUser().getUid();

        syncedProjects = findViewById(R.id.synced_projects_text_view);

        mFirestoreList = findViewById(R.id.recycler_view_recent_projects);
        mFirestoreList2 = findViewById(R.id.recycler_view_collaborater_projects);

        DocumentReference documentReference = firebaseFirestore.collection("users").document(userID);

        documentReference.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            collaboraterID = snapshot.getString("collaborater");

                            //String ID = collaboraterID.trim();

                            if(TextUtils.isEmpty(collaboraterID))
                            {
                                return;
                            }

                            syncedProjects.setText("Synced Projects of User: " + collaboraterID);

                            query2 = firebaseFirestore.collection("users").document(collaboraterID).collection("projects");

                            FirestoreRecyclerOptions<ProjectsModel> options2 = new FirestoreRecyclerOptions.Builder<ProjectsModel>()
                                    .setQuery(query2, new SnapshotParser<ProjectsModel>() {
                                        @NonNull
                                        @Override
                                        public ProjectsModel parseSnapshot(@NonNull DocumentSnapshot snapshot) {

                                            ProjectsModel projectsModel = snapshot.toObject(ProjectsModel.class);
                                            String projectId = snapshot.getId();
                                            Log.d("MODEL_TITLE", snapshot.getId());
                                            projectsModel.setProject_Id(projectId);

                                            return projectsModel;

                                        }
                                    })
                                    .build();


                            adapter2 = new FirestoreSyncAdapter(options2, RecentProject.this);

                            mFirestoreList2.setHasFixedSize(true);
                            mFirestoreList2.setLayoutManager(new LinearLayoutManager(RecentProject.this));
                            mFirestoreList2.setAdapter(adapter2);
                            adapter2.startListening();


                        }else
                        {
                            Toast.makeText(RecentProject.this, "Wrong Code Input", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(RecentProject.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


        //Query
        Query query = firebaseFirestore.collection("users").document(userID).collection("projects");





        //RecyclerOptions
        FirestoreRecyclerOptions<ProjectsModel> options = new FirestoreRecyclerOptions.Builder<ProjectsModel>()
                .setQuery(query, new SnapshotParser<ProjectsModel>() {
                    @NonNull
                    @Override
                    public ProjectsModel parseSnapshot(@NonNull DocumentSnapshot snapshot) {

                            ProjectsModel projectsModel = snapshot.toObject(ProjectsModel.class);
                            String projectId = snapshot.getId();
                            Log.d("MODEL_TITLE", snapshot.getId());
                            projectsModel.setProject_Id(projectId);

                            return projectsModel;

                    }
                })
                .build();





        adapter = new FirestoreAdapter(options, this);

        mFirestoreList.setHasFixedSize(true);
        mFirestoreList.setLayoutManager(new LinearLayoutManager(this));
        mFirestoreList.setAdapter(adapter);

    }


    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        switch (item.getItemId()){
            case R.id.action_home:
                finish();
                startActivity(new Intent(RecentProject.this , MainActivity.class));
                return true;
            case R.id.action_projects:
                return true;
            case R.id.action_templates:
                finish();
                startActivity(new Intent(RecentProject.this , Templates.class));
                return true;
            case R.id.action_settings:
                finish();
                startActivity(new Intent(RecentProject.this , Settings.class));
                return true;
        }

        return  super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }



    @Override
    public void onItemClick(ProjectsModel snapshot , int position) {
        Intent intent = new Intent(this , ProjectDetail.class);
        intent.putExtra(ProjectDetail.PROJECT_TITLE , snapshot.getProject_Id());
        intent.putExtra(ProjectDetail.PROJECT_LOCATION , snapshot.getLocation());
        intent.putExtra(ProjectDetail.PROJECT_BUDGET , snapshot.getBudget());
        startActivity(intent);
        Log.d("ITEM_CLICK" , "Clicked an item: " + position + " and the ID: " + snapshot.getProject_Id());
    }
    public void onItemClick2(ProjectsModel snapshot , int position) {
        Intent intent = new Intent(this , ProjectDetail.class);
        intent.putExtra(ProjectDetail.PROJECT_TITLE , snapshot.getProject_Id());
        intent.putExtra(ProjectDetail.PROJECT_LOCATION , snapshot.getLocation());
        intent.putExtra(ProjectDetail.PROJECT_BUDGET , snapshot.getBudget());
        intent.putExtra(ProjectDetail.USER_ID , collaboraterID);
        startActivity(intent);
        Log.d("ITEM_CLICK" , "Clicked an item: " + position + " and the ID: " + snapshot.getProject_Id());
    }



    public interface OnItemClickListener{
        void onItemClicked(DocumentSnapshot documentSnapshot , int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener)
    {
        this.listener = listener;
    }


    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();

    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}