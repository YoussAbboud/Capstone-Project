package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RestaurentTemplate extends AppCompatActivity {

    ImageButton backButton , addButton;

    TextView projectTitle, projectLocation , projectBudget, task1Title, task1Desc, task1Labor,
            task2Title, task2Desc, task2Labor;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;


    String userID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurent_template);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        userID = fAuth.getCurrentUser().getUid();

        backButton = findViewById(R.id.restaurent_template_back_button);

        addButton = findViewById(R.id.restaurent_template_add_button);

        projectTitle = findViewById(R.id.restaurent_template_title);
        String pTitle = projectTitle.getText().toString();

        projectLocation = findViewById(R.id.restaurent_template_location);
        String pLocation = projectLocation.getText().toString();

        projectBudget = findViewById(R.id.restaurent_template_budget);
        String pBudget = projectBudget.getText().toString();

        task1Title = findViewById(R.id.restaurent_template_task1_title);
        String t1Title = task1Title.getText().toString();

        task1Desc = findViewById(R.id.restaurent_template_task1_desc);
        String t1Desc = task1Desc.getText().toString();

        task1Labor = findViewById(R.id.restaurent_template_task1_labor);
        String t1Labor = task1Labor.getText().toString();

        task2Title = findViewById(R.id.restaurent_template_task2_title);
        String t2Title = task2Title.getText().toString();

        task2Desc = findViewById(R.id.restaurent_template_task2_desc);
        String t2Desc = task2Desc.getText().toString();

        task2Labor = findViewById(R.id.restaurent_template_task2_labor);
        String t2Labor = task2Labor.getText().toString();

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DocumentReference documentReference = fStore.collection("users").document(userID).collection("projects").document(pTitle);

                Map<String, Object> project = new HashMap<>();
                project.put("title", pTitle);
                project.put("location", pLocation);
                project.put("budget", pBudget);

                documentReference.set(project);

                DocumentReference documentReference2 = fStore.collection("users").document(userID).collection("projects").document(pTitle).collection("tasks").document(t1Title);
                Map<String, Object> Task = new HashMap<>();
                Task.put("title", t1Title);
                Task.put("description", t1Desc);
                Task.put("labor", t1Labor);

                documentReference2.set(Task);


                DocumentReference documentReference3 = fStore.collection("users").document(userID).collection("projects").document(pTitle).collection("tasks").document(t2Title);
                Map<String, Object> Task2 = new HashMap<>();
                Task2.put("title", t2Title);
                Task2.put("description", t2Desc);
                Task2.put("labor", t2Labor);

                documentReference3.set(Task2);

                Toast.makeText(RestaurentTemplate.this, "Template Added to your Projects", Toast.LENGTH_SHORT).show();
                finish();

            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}