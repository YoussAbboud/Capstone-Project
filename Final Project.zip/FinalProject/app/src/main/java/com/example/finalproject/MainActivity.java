package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {
    TextView addButton, recentProjectButton, viewTemplatesButton;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;

    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();


        if(fAuth.getCurrentUser() == null )
        {
            startActivity(new Intent(getApplicationContext() , Login.class));
            finish();
        }


        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        toolbar.setTitle("");

        setSupportActionBar(toolbar);
        toolbar.setLeft(R.drawable.baseline_home_24);

        addButton = findViewById(R.id.add_project_button);

        viewTemplatesButton = findViewById(R.id.view_templates_button);

        recentProjectButton = findViewById(R.id.recent_project_button);

        viewTemplatesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext() , Templates.class));
                
            }
        });


        recentProjectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext() , RecentProject.class));
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext() , AddProject.class));
            }
        });


    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        switch (item.getItemId()){
            case R.id.action_home:
                startActivity(new Intent(getApplicationContext() , MainActivity.class));
                return true;
            case R.id.action_projects:
                finish();
                startActivity(new Intent(getApplicationContext() , RecentProject.class));
                return true;
            case R.id.action_templates:
                finish();
                startActivity(new Intent(getApplicationContext() , Templates.class));
                return true;
            case R.id.action_settings:
                finish();
                startActivity(new Intent(getApplicationContext() , Settings.class));
                return true;
        }

        return  super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }


}