package com.example.finalproject;

public class ProjectsModel {

    private String project_Id;

    private String title;
    private String location;
    private String budget;

    private ProjectsModel(){}

   private ProjectsModel(String project_id, String title, String location, String budget)
    {
        this.project_Id = project_id;
        this.title = title;
        this.location = location;
        this.budget = budget;
    }

    public String getProject_Id() {
        return project_Id;
    }

    public void setProject_Id(String project_Id) {
        this.project_Id = project_Id;
    }

    public String getTitle() {
        return title;
    }

    public String getLocation() {
        return location;
    }

    public String getBudget() {
        return budget;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setBudget(String budget) {
        this.budget = budget;
    }
}
