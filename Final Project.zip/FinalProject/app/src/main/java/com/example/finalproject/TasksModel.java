package com.example.finalproject;

public class TasksModel {

    private String task_Id;

    private String title;
    private String description;
    private String labor;

    private TasksModel(){}

    private TasksModel(String task_id, String title, String description, String labor)
    {
        this.task_Id = task_id;
        this.title = title;
        this.description = description;
        this.labor = labor;
    }

    public String getTask_Id() {
        return task_Id;
    }

    public void setTask_Id(String task_Id) {
        this.task_Id = task_Id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLabor() {
        return labor;
    }

    public void setLabor(String labor) {
        this.labor = labor;
    }
}
