package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class Templates extends AppCompatActivity {

    TextView kitchenTemp , bathroomTemp, restaurentTemp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_templates);

        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        toolbar.setTitle("");

        setSupportActionBar(toolbar);
        toolbar.setLeft(R.drawable.baseline_home_24);

        kitchenTemp = findViewById(R.id.kitchen_text_view);

        bathroomTemp = findViewById(R.id.bathroom_text_view);

        restaurentTemp = findViewById(R.id.restaurent_text_view);

        restaurentTemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Templates.this , RestaurentTemplate.class));
            }
        });

        bathroomTemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Templates.this , BathroomTemplate.class));
            }
        });


        kitchenTemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Templates.this , KitchenTemplate.class));
            }
        });






    }


    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        switch (item.getItemId()){
            case R.id.action_home:
                finish();
                startActivity(new Intent(Templates.this , MainActivity.class));
                return true;
            case R.id.action_projects:
                finish();
                startActivity(new Intent(Templates.this , RecentProject.class));
                return true;
            case R.id.action_templates:
                return true;
            case R.id.action_settings:
                finish();
                startActivity(new Intent(Templates.this , Settings.class));
                return true;
        }

        return  super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }


}