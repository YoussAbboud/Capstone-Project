package com.example.finalproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class FirestoreAdapter extends FirestoreRecyclerAdapter<ProjectsModel , FirestoreAdapter.ProjectsViewHolder> {

    private OnListItemClick onListItemClick;

    public FirestoreAdapter(@NonNull FirestoreRecyclerOptions<ProjectsModel> options , OnListItemClick onListItemClick) {
        super(options);
        this.onListItemClick = onListItemClick;
    }

    @Override
    protected void onBindViewHolder(@NonNull ProjectsViewHolder holder, int position, @NonNull ProjectsModel model) {
        holder.project_title.setText("Title: "+model.getTitle());
        holder.project_location.setText("Location: "+model.getLocation());
        holder.project_budget.setText("Budget: $"+model.getBudget());
    }



    @NonNull
    @Override
    public ProjectsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recent_project_item , parent , false);

        return new ProjectsViewHolder(view);
    }

    class ProjectsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView project_title;
        private TextView project_location;
        private TextView project_budget;

        public ProjectsViewHolder(@NonNull View itemView) {
            super(itemView);

            project_title = itemView.findViewById(R.id.project_recent_title);
            project_location = itemView.findViewById(R.id.project_recent_location);
            project_budget = itemView.findViewById(R.id.project_recent_budget);

            itemView.setOnClickListener(this);

        }





        @Override
        public void onClick(View v) {
            onListItemClick.onItemClick(getItem(getAdapterPosition()) , getAdapterPosition());
        }
    }

public interface OnListItemClick {
    void onItemClick(ProjectsModel snapshot , int position);
}

}
