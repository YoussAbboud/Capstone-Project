package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.HashMap;
import java.util.Map;

public class Settings extends AppCompatActivity {

    Button logoutBtt, shareBtt, syncBtt, resetBtt;

    EditText syncCode;

    TextView email , password , changePassword;



    FirebaseAuth fAuth;
    FirebaseFirestore fStore;

    String userID;
    String uPassword;
    FirebaseUser user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        logoutBtt = findViewById(R.id.logout_btt);

        shareBtt = findViewById(R.id.share_btt);

        syncBtt = findViewById(R.id.sync_btt);

        resetBtt = findViewById(R.id.reset_btt);

        syncCode = findViewById(R.id.edit_text_sync_code);

        email = findViewById(R.id.email_user_text);
        password = findViewById(R.id.password_user_text);
        uPassword = password.getText().toString();

        changePassword = findViewById(R.id.change_password_text_view);


        userID = fAuth.getCurrentUser().getUid();
        user = fAuth.getCurrentUser();

        DocumentReference documentReference = fStore.collection("users").document(userID);

        documentReference.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot snapshot) {
                if(snapshot.exists()) {
                    syncCode.setText(snapshot.getString("collaborater"));
                }
            }
        });

        String uEmail = fAuth.getCurrentUser().getEmail();
        //String uPass = fAuth.getCurrentUser().get

        resetBtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DocumentReference documentReference = fStore.collection("users").document(userID);

                documentReference.update(
                        "collaborater" , ""

                );
                startActivity(new Intent(Settings.this , Settings.class));
                finish();
            }
        });

        syncBtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(syncCode.getText().toString()))
                {
                    syncCode.setError("User Code is Required");
                    return;
                }

                DocumentReference documentReference = fStore.collection("users").document(userID);

                documentReference.update(
                        "collaborater" , syncCode.getText().toString()

                );

                Toast.makeText(Settings.this, "Projects Synced", Toast.LENGTH_SHORT).show();

            }
        });

        shareBtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, "Use this Code to Collaborate on my Projects: "+'\n'+ userID );
                startActivity(Intent.createChooser(intent, "Please Share via:"));
            }
        });

        logoutBtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.this , Login.class));
                finish();
                FirebaseAuth.getInstance().signOut();

            }
        });

        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText resetPassword = new EditText(Settings.this);
                android.app.AlertDialog.Builder builder1 = new android.app.AlertDialog.Builder(Settings.this);
                builder1.setIcon(R.drawable.baseline_delete_24);
                builder1.setTitle("Reset Password");
                builder1.setMessage("Enter Your New Password");
                builder1.setView(resetPassword);
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {


                                dialog.cancel();

                                String newPassword = resetPassword.getText().toString();

                                if(TextUtils.isEmpty(newPassword))
                                {
                                    resetPassword.setError("Password is Required.");
                                    return;
                                }

                                if(newPassword.length() < 6){
                                    resetPassword.setError("Password must be bigger then 6 characters");
                                    return;
                                }

                                if(uPassword.equals(newPassword))
                                {
                                    resetPassword.setError("New Password & Old Match");
                                    return;
                                }

                                DocumentReference documentReference3 = fStore.collection("users").document(userID);

                                user.updatePassword(newPassword).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        documentReference3.update(
                                                "password" , newPassword

                                        );
                                        Toast.makeText(Settings.this, "Password Changed Successfully", Toast.LENGTH_SHORT).show();
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(Settings.this, "password Reset Failed "  +e.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                android.app.AlertDialog alert11 = builder1.create();
                alert11.show();

            }
        });


        DocumentReference documentReference2 = fStore.collection("users").document(userID);
        documentReference2.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                if(value != null) {
                    password.setText(value.getString("password"));
                }
                else{
                    return;
                }
            }
        });

        email.setText(uEmail);


        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        toolbar.setTitle("");

        setSupportActionBar(toolbar);
        toolbar.setLeft(R.drawable.baseline_home_24);

    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item){

        switch (item.getItemId()){
            case R.id.action_home:
                startActivity(new Intent(Settings.this , MainActivity.class));
                return true;
            case R.id.action_projects:
                startActivity(new Intent(Settings.this , RecentProject.class));
                return true;
            case R.id.action_templates:
                startActivity(new Intent(Settings.this , RecentProject.class));
                return true;
            case R.id.action_settings:
                return true;
        }

        return  super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

}