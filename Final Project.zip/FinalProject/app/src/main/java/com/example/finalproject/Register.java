package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
    EditText rFullName, rEmail , rPassword, rCPassword ,rPhone;
    Button regButton;
    TextView loginBtt;

    ImageView hidePass , showPass;

    String userID;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;

    ProgressBar progressBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        rEmail = findViewById(R.id.email_register_edit_text);
        rPassword = findViewById(R.id.password_register_edit_text);
        rCPassword = findViewById(R.id.confirm_password_register_edit_text);

        regButton = findViewById(R.id.register_button);
        loginBtt = findViewById(R.id.login_text_view);

        hidePass = findViewById(R.id.hide_password_checkbox_register);
        showPass = findViewById(R.id.show_password_checkbox_register);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        progressBar = findViewById(R.id.progressBar);

        if(fAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext() , MainActivity.class));
            finish();
        }

        showPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                rPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                rCPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                showPass.setVisibility(View.GONE);

                hidePass.setVisibility(View.VISIBLE);


            }
        });

        hidePass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hidePass.setVisibility(View.GONE);
                rPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                rCPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                showPass.setVisibility(View.VISIBLE);
            }
        });


        regButton.setOnClickListener(new View.OnClickListener() {
            private String TAG = "REGISTER_FIREBASE";

            @Override
            public void onClick(View v) {
                String email = rEmail.getText().toString();
                String password = rPassword.getText().toString();
                String cPassword = rCPassword.getText().toString();

                if(TextUtils.isEmpty(email))
                {
                    rEmail.setError("Email is Required.");
                    return;
                }

                if(TextUtils.isEmpty(password))
                {
                    rPassword.setError("Password is Required.");
                    return;
                }
                if(TextUtils.isEmpty(cPassword))
                {
                    rPassword.setError("Password Confirmation is Required.");
                    return;
                }

                if(password.length() < 6){
                    rPassword.setError("Password must be bigger then 6 characters");
                    return;
                }

                if(!password.equals(cPassword))
                {
                    rCPassword.setError("Password & Confirmation must Match");
                    return;
                }



                    progressBar.setVisibility(View.VISIBLE);

                    fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {


                                fAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful())
                                        {
                                            userID = fAuth.getCurrentUser().getUid();
                                            DocumentReference documentReference = fStore.collection("users").document(userID);

                                            Map<String , Object> user = new HashMap<>();
                                            user.put("email" , email);
                                            user.put("password" , password);
                                            user.put("collaborater" , " ");

                                            documentReference.set(user).addOnFailureListener(new OnFailureListener() {


                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Log.d(TAG, "onFailure: " + e.toString());
                                                }
                                            });


                                            Toast.makeText(Register.this, "User Created Successfully, Please check your email for verification", Toast.LENGTH_LONG).show();
                                            finish();
                                            startActivity(new Intent(getApplicationContext(), Login.class));
                                        }
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.d("This email" , e.getMessage());
                                    }
                                });



                            } else {
                                Toast.makeText(Register.this, "Error while Creating User: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                            }
                        }
                    });
                }
        });


        loginBtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext() , Login.class));
            }
        });


    }

}